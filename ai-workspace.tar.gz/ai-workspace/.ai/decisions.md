# Technical Decisions

## 2026-04-24 — Use `.ai/` not `.claude/` for repo memory
**Decision**: Store persistent memory in `.ai/` directory, not inside `.claude/`.
**Reason**: Model-agnostic. `.claude/` is Claude Code-specific; `.ai/` works identically in Cursor, Kilo, GPT, and any future tool. Any AI can be instructed to "read .ai/ first."
**Trade-off**: Requires a line in each tool's config/prompt to load `.ai/`; `.claude/` would auto-load in Claude Code only.

## 2026-04-24 — Use SecondBrain/ as Obsidian vault
**Decision**: `SecondBrain/` is the Obsidian vault root (`.obsidian/` config was already present).
**Reason**: User already had the vault initialized. Aligns with the strategic vault layer described in the spec.
**Trade-off**: Content is machine-local until sync is configured.

## 2026-04-24 — AGENTS.md is the canonical entrypoint; all other rule files are pointers
**Decision**: Use `AGENTS.md` (the emerging open standard — Cursor, OpenCode, Zed, Antigravity, Codex, Windsurf) as the single source of truth. `CLAUDE.md`, `.cursorrules`, `.cursor/rules/main.mdc`, `.windsurfrules`, `.kilocode/rules.md` are thin pointers that reference it.
**Reason**: Eliminates rule drift across tools. Adding a new tool = add one pointer file, not re-duplicate logic. `.ai/` stays where it is (already tool-agnostic). Solves the token-waste and framework-fragmentation problem in one stroke.
**Trade-off**: One extra redirect per tool vs. per-tool duplicated rules that silently diverge over time. Also: some tools auto-load the pointer but not `AGENTS.md` — those need the bootstrap prompt from `SecondBrain/Prompts/bootstrap.md`.

## 2026-04-24 — Personal assistant agents live alongside coding agents in `.agents/`
**Decision**: Daily-use personal assistant roles (`assistant`, `scheduler`, `reminder`) share the `.agents/` directory with coding roles (`architect`, `debugger`, etc.). State lives in `SecondBrain/Assistant/` (schedule, reminders, inbox).
**Reason**: Same activation pattern everywhere (*"Use the `<role>` role"*). Cross-project state (schedule, reminders) belongs in the strategic vault, not any one project's `.ai/`.
**Trade-off**: `.agents/` mixes two concerns (code vs. life), but the role-file format is identical and the alternative (two parallel systems) would be worse. If the list grows past ~10 roles, split by subfolder.

## 2026-04-24 — Pure markdown, no automation scripts
**Decision**: Entire system is plain markdown files — no shell scripts, no automation.
**Reason**: Maximum portability. Works on any machine, any OS, any AI tool, with zero setup. Compounds knowledge without lock-in.
**Trade-off**: Manual discipline required to keep `.ai/handoff.md` and `.ai/tasks.md` updated.
