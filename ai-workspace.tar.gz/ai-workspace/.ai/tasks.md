# Tasks

## This Sprint
- [x] Create CLAUDE.md with session start/end protocol
- [x] Create .ai/ folder with all 6 memory files
- [x] Create .agents/ folder with 5 role prompts
- [x] Create SecondBrain/ vault structure with templates
- [x] Create .claude/rules/ for Claude Code-specific rules
- [x] Create top-level TODO.md, ARCHITECTURE.md, DECISIONS.md

## Next Sprint
- [x] Make workspace framework-agnostic (AGENTS.md + tool pointers)
- [x] Add personal assistant agents (assistant, scheduler, reminder)
- [x] Add SecondBrain/Assistant/ daily state files
- [x] Populate SecondBrain/Prompts/ with 3-5 reusable prompts (bootstrap.md — coding + assistant variants = 2; add more as discovered)
- [ ] Test AGENTS.md pointer pattern in Cursor or Kilo end-to-end
- [ ] Run first real morning check-in via `assistant` role
- [ ] Apply .ai/ template to first real project
- [ ] Add a daily note template to SecondBrain/Templates/

## Backlog
- [ ] Set up git version control for this workspace
- [ ] Consider Obsidian Sync or git-based sync for SecondBrain/
- [ ] Build a "new project setup" checklist prompt
- [ ] Add a `bugs.md` template for tracking issues per project
- [ ] Archive old `PersistentGuides/` once superseded content is migrated into `.ai/` + `AGENTS.md`
