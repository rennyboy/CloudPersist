# System Architecture

## Overview
Two-layer persistent memory system for solo AI-powered builder workflows.

## Layer 1: Repo Memory (Execution Layer)
```
project/
└── .ai/
    ├── memory.md        Project identity, stack, constraints
    ├── handoff.md       Last session state → next actions
    ├── tasks.md         Sprint tasks + backlog
    ├── decisions.md     Dated technical decisions
    ├── coding_rules.md  Style, conventions, AI interaction rules
    └── architecture.md  This file — system structure
```
**Scope**: Per project. Stays in the repo. Model-agnostic.

## Layer 2: Strategic Vault (Knowledge Layer)
```
SecondBrain/
├── Projects/       One note per active project (high-level)
├── Knowledge/      Technical concepts, references, research
├── Prompts/        Reusable AI prompts with context + output format
├── Decisions/      Cross-project strategic decisions
├── Bugs/           Recurring bug patterns and fixes
├── Learnings/      What you learned, mistakes made
├── Daily Notes/    YYYY-MM-DD sessions and reflections
└── Templates/      Copy-paste starters for .ai/ and vault notes
```
**Scope**: Machine-local Obsidian vault. Cross-project knowledge.

## Layer 3: Agent Roles
```
project/
└── .agents/
    ├── architect.md   System design role
    ├── debugger.md    Root cause analysis role
    ├── refactor.md    Code quality role
    ├── pm.md          Task planning role
    └── reviewer.md    Code review role
```
**Scope**: Per project. Reusable across sessions and AI tools.

## Layer 4: Claude Code Integration
```
project/
├── CLAUDE.md          Auto-loaded by Claude Code every session
└── .claude/
    └── rules/
        ├── memory-workflow.md   Enforce .ai/ read/write behavior
        └── token-saving.md     Enforce scoped, efficient prompting
```
**Scope**: Claude Code sessions only. Layered on top of Layers 1-3.

## Data Flow
```
Session start:
  CLAUDE.md → instructs Claude to read .ai/memory.md + handoff.md
  Agent role loaded if specified
  
During session:
  Agent performs task using loaded context
  
Session end:
  .ai/handoff.md updated
  .ai/tasks.md updated if needed
  .ai/decisions.md appended if major decision made
  
Periodically:
  SecondBrain/ updated with learnings, prompts, decisions
```
