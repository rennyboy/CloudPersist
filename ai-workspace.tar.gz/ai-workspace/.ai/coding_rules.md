# Coding Rules & Conventions

## Memory File Rules
- `.ai/` files stay under 50 lines each — if growing, split into topic files
- `handoff.md` uses present/past tense, max 20 lines
- `decisions.md` entries always include: Decision, Reason, Trade-off
- `tasks.md` uses checkboxes `[ ]` / `[x]` with clear sprint sections

## AI Interaction Rules
- Always load `.ai/memory.md` and `.ai/handoff.md` before any task
- One role per session — don't mix architect and debugger in the same chat
- Update `.ai/handoff.md` before ending any session with meaningful work
- Scope prompts narrowly: "Read `.ai/architecture.md` section X only. Do Y."

## Vault Rules (SecondBrain/)
- One note per concept — no mega-notes
- Use YYYY-MM-DD prefix for daily notes: `2026-04-24 Daily.md`
- Decision notes go in `Decisions/`, not inline in project notes
- Prompts in `Prompts/` use the format: context, task, output format

## General Style
- Markdown only — no HTML in notes
- Headers use `##` not bold text as section markers
- Bullet points over paragraphs for scannability
- No trailing commentary — notes are reference, not narrative
