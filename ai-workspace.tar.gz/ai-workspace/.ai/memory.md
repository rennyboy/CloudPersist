# Project Memory

## Index (read first — load only the section you need)
- `Identity` — lines 10-15
- `Purpose` — lines 17-19
- `Stack` — lines 21-26
- `Priorities` — lines 28-33
- `Constraints` — lines 35-40
- `Context` — lines 42-46

## Identity
- **Name**: AI Workspace — Multi-AI Persistent Memory System
- **Owner**: rennyboyjr@gmail.com
- **Created**: 2026-04-24
- **Canonical entrypoint**: `AGENTS.md`

## Purpose
Model-agnostic persistent memory + agent role system that eliminates re-prompting and enables seamless handoff across AI tools (Claude Code, Cursor, Antigravity, Kilo, OpenCode, Zed, Windsurf, GPT).

## Stack
- **Format**: Pure markdown (zero dependencies)
- **Vault**: Obsidian (`SecondBrain/`)
- **Entrypoint**: `AGENTS.md` (universal) + thin tool pointers (`CLAUDE.md`, `.cursorrules`, `.windsurfrules`, `.kilocode/rules.md`)
- **Integration**: Any tool that reads a rules file or accepts a bootstrap prompt
- **Version control**: None yet — run `git init` when content stabilizes

## Priorities
1. Keep `.ai/` files concise and scoped — under 50 lines each
2. Apply the template to every new real project (copy from `SecondBrain/Templates/`)
3. Grow the strategic vault with reusable prompts, learnings, and decisions
4. Use personal assistant agents daily (assistant, scheduler, reminder)
5. Refine agent roles from real usage — promote patterns to `SecondBrain/Prompts/`

## Constraints
- Pure markdown, no automation scripts — portable, zero lock-in
- `.ai/*` files stay under 50 lines each (handoff under 25)
- This workspace **is** the system, not a product
- Vault content stays machine-local until sync is configured
- Rule files other than `AGENTS.md` are thin pointers — do not duplicate logic

## Context
- Solo founder / builder workflow
- Likely Laravel / SaaS / ERP / HRMIS projects
- Claude Code Pro — use for high-value tasks only; cheap tools for small edits
- Personal assistant agents run off `SecondBrain/Assistant/` state files
