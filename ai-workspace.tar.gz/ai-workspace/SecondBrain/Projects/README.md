# Projects

One note per active project. Use this format:

```
# [Project Name]
**Status**: Active / On Hold / Shipped
**Stack**: [tech stack]
**Repo**: [path or URL]
**Goal**: [one sentence]
**Links**: [relevant docs, issues, designs]
```

Archive shipped projects by adding `[Shipped]` prefix to the filename.
