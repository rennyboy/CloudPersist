# Projects INDEX — Registry

> Always-loaded at session start. One row per project that uses this brain.
>
> Cap: 50 lines. If you have more than 50 active projects, you have bigger problems.

## Active

| Slug | Path | Stack | Last touched | Status |
|---|---|---|---|---|
| ai-workspace | `~/Downloads/projects/ai-workspace` | meta / template hub | 2026-04-26 | active |
| myApp | `~/Downloads/projects/myApp` | (TBD) | 2026-04-26 | active |

## Archived

_(none yet — when a project is done, move its row here and add `closed: YYYY-MM-DD`)_

---

## Per-project page (optional)

A project may have a deeper page at `Projects/<slug>.md` covering: goals, owner, deadlines, links to its `.ai/handoff.md` and `.ai/memory.md`. Create only when the row above isn't enough.

## Adding a new project

1. Run `ai-workspace/new-project.sh <slug>` (or scaffold by hand from `.template/`).
2. From the new project: `ln -s ~/SecondBrain SecondBrain` (or run `scripts/bootstrap.sh` if you copied it).
3. Add a row above.
4. If non-trivial, create `Projects/<slug>.md` from `Templates/project.md`.
