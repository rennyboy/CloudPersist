# Error Capture Prompt

> Use after hitting an error or surprise. The loop only evolves if errors get captured.

---

I just hit this error/issue:

```
<paste error message, stack trace, or describe surprise>
```

Project: `<slug>`
Context: <what I was trying to do>

Please:

1. Search `~/SecondBrain/Errors/INDEX.md` for matching symptoms.
2. **If a match exists:**
   - Don't create a new file. Open the existing entry.
   - Increment `hits` in its frontmatter.
   - Append a line to its `## Recurrence log`: today's date, project, brief note.
   - If `<project>` is not in `affects:`, add it.
   - In `Errors/INDEX.md`, increment the row's `Hits` and update `Affects`.
   - If `Hits >= 3` OR `Affects` has ≥2 distinct projects → mark the row with 🔼.
3. **If no match:**
   - Create `~/SecondBrain/Errors/<YYYY-MM-DD>-<slug>.md` from `Templates/error.md`.
   - Fill all sections honestly. If you don't know root cause yet, mark `status: open` and put what you've ruled out under `## Context`.
   - Add a row to `Errors/INDEX.md`.
4. Report back: which path was taken, file path, current `Hits` count.

Do **not** ask me clarifying questions before doing the lookup — the lookup itself often answers them.
