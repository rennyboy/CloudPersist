# Session Start Prompt

> Paste this (or have it auto-loaded via tool integration) at the start of any new chat that touches a project served by this brain.

---

Read in this order, only the listed files:

1. `~/SecondBrain/INDEX.md`
2. `~/SecondBrain/Errors/INDEX.md` — failure library, scan for symptoms relevant to today's task
3. `~/SecondBrain/Knowledge/INDEX.md` — distilled rules
4. `~/SecondBrain/Decisions/INDEX.md` — recent active decisions
5. `~/SecondBrain/Projects/INDEX.md` — confirm the project I'm about to work on is registered
6. `<project>/.ai/handoff.md` — last session state
7. `<project>/.ai/memory.md` (top 15-line index only) — load specific sections only if the task needs them

Then confirm in **one line**:

`Loaded: brain[errors,knowledge,decisions,projects] + handoff + memory[<sections>]. Ready.`

Wait for the task. **Do not** read individual entry files unless an INDEX row matches the task at hand.
