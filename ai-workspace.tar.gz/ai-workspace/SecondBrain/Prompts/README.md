# Prompts

Reusable AI prompts that have worked well in practice.

## Format for Each Prompt

```markdown
# [Prompt Name]
**Use for**: [when to use this]
**Tool**: Claude Code / GPT / Any

## Context to Load
[what files or context to load before using]

## Prompt
[the actual prompt text]

## Expected Output
[what good output looks like]
```

## Tips
- Prompts here should be battle-tested — save after you've used one successfully
- Include the context-loading step — a prompt without context is half a prompt
- Note which AI tools it works best with
