# Promotion Review Prompt

> Run weekly (or whenever `Errors/INDEX.md` has 🔼 markers). Distills repeated entries into stable Knowledge rules.

---

Walk the brain in this order:

### 1. Errors → Knowledge

Read `~/SecondBrain/Errors/INDEX.md`. For each row marked 🔼:

- Open the entry.
- Confirm the trigger (`hits >= 3` or `affects` has ≥2 projects).
- Decide: is there a transferable rule here?
  - **If yes:** Create or extend `~/SecondBrain/Knowledge/<topic>.md`. State the rule in prescriptive form (`When X, do Y. Why: Z.`). Add 1 line to `Knowledge/INDEX.md`. Delete the source error file. Remove its row from `Errors/INDEX.md`.
  - **If no (one-off, project-specific, or stale):** unmark 🔼 and add a `# Reviewed YYYY-MM-DD` note to the entry.

### 2. Learnings → Knowledge

Read `~/SecondBrain/Learnings/`. For each file with `applied-times >= 1` AND `confidence: high` (or seen in 2+ projects):

- Promote to Knowledge using the rule above.
- Delete the Learning.

### 3. Knowledge → archive

Read `~/SecondBrain/Knowledge/INDEX.md`. For each entry not referenced in the last 90 days, OR explicitly superseded:

- Move file to `Knowledge/archive/`.
- Remove from `Knowledge/INDEX.md`.
- Note in `_meta/evolution-log.md`.

### 4. Index hygiene

For each of `Errors/INDEX.md`, `Knowledge/INDEX.md`, `Decisions/INDEX.md`, `Projects/INDEX.md`:

- Check it doesn't exceed its line cap (see `_meta/evolution-loop.md`).
- Verify every file in the directory has an index row.
- Verify every index row points to an existing file.

### 5. Log

Append one line per promotion/demotion/archive to `_meta/evolution-log.md`. Format: `YYYY-MM-DD | <event> | <details>`.

### 6. Report

Output a summary:
- N errors promoted, M demoted, K reviewed-but-kept
- Index sizes (lines) before / after
- Anything that looked broken (orphan files, missing INDEX rows, expired Decisions)
