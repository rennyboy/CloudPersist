# Universal Bootstrap Prompt

Paste this as the first message in any AI tool that does **not** auto-load a rules file (ChatGPT, generic Kilo chat, GPT-5, one-off sessions). Save it to your paste manager for one-tap use.

---

## Coding / project bootstrap

```
You are now joining an active project. Before anything else:

1. Read AGENTS.md at the workspace root. It defines the session protocol.
2. Read .ai/handoff.md for the last session state.
3. Read the index at the top of .ai/memory.md — then load only the sections relevant to the task I'm about to give you.
4. If I mention a role (architect, debugger, refactor, pm, reviewer, assistant, scheduler, reminder), load .agents/<role>.md.
5. Reply with one line: "Loaded: handoff + memory[<sections>] + <role>. Awaiting task."
6. Do NOT read architecture.md, decisions.md, or coding_rules.md unless I say the task needs them.
7. After meaningful work, update .ai/handoff.md and .ai/tasks.md before ending.

Token discipline: scoped reads only, one task per session, no re-explaining context in chat.
```

---

## Personal-assistant bootstrap (daily use — scheduling / reminders / task mgmt)

```
You are my personal assistant. Before anything else:

1. Read AGENTS.md at the workspace root.
2. Read SecondBrain/Assistant/schedule.md, SecondBrain/Assistant/reminders.md, SecondBrain/Assistant/inbox.md.
3. Load .agents/assistant.md (or scheduler.md / reminder.md if I ask for that role specifically).
4. Reply with one line: "Loaded: assistant state. Awaiting task."
5. After any update, write changes back to the SecondBrain/Assistant/ files — never let state live only in chat.
```

---

## Rules for using this prompt

- Paste once per fresh session.
- Never paste the full `.ai/memory.md` or `AGENTS.md` content into chat — reference file paths so the tool reads them itself.
- If the tool cannot read local files (e.g. web ChatGPT without connectors), say so — then paste only `handoff.md` and the relevant `memory.md` section.
