# Errors INDEX — Failure Library

> Always-loaded at session start. The brain's "have I seen this before?" lookup.
>
> Cap: 200 lines. When exceeded, promote ripe entries to `Knowledge/` and archive stale ones to `Daily Notes/`.

## How to read this

| Symptom (the surface error you'd see) | Fix file | Hits | Affects |
|---|---|---|---|

(table grows below — one row per distinct error)

---

## Entries

<!-- Add entries here. Format:
| `error message excerpt` | [yyyy-mm-dd-slug](./yyyy-mm-dd-slug.md) | 1 | myApp |
-->

_(empty — no errors captured yet)_

---

## How to add an entry

1. Hit an error → copy `Templates/error.md` to `Errors/YYYY-MM-DD-<slug>.md`.
2. Fill: symptom, root cause, fix, prevention, `affects:` list.
3. Add 1 row to the table above.
4. If symptom matches an existing row → don't create a new file. Increment `Hits` in that row, append the new project to `Affects`, add a session note to that file.
5. If `Hits >= 3` or `Affects` lists ≥2 distinct projects → mark the row with `🔼` (ready for promotion) and review at next promotion cycle.

## Promotion-ready (🔼)

_(none yet)_
