# Decisions INDEX — Major Calls

> Always-loaded at session start. Cross-project architectural / strategic decisions.
>
> Cap: 100 lines. Year-old decisions move to `Decisions/YYYY/` and out of this index unless still load-bearing.

## Entries

| Date | Decision (one line) | File | Status |
|---|---|---|---|
| 2026-04-26 | SecondBrain lives at `~/SecondBrain`, symlinked into projects | [2026-04-26-secondbrain-location.md](./2026-04-26-secondbrain-location.md) | active |

## Conventions

- Format per entry: **Decision / Reason / Trade-off / Revisit-if**.
- Status values: `active`, `superseded`, `reverted`, `expired`.
- Revisit-if line gives future-you a trigger to re-evaluate.
