# Decisions

Strategic decisions that span multiple projects or affect your overall approach.

Per-project technical decisions go in the project's `.ai/decisions.md`.
This folder is for meta-level choices: tools, workflows, business direction, partnerships.

## Format
Use the template at `../Templates/decision.md`.
