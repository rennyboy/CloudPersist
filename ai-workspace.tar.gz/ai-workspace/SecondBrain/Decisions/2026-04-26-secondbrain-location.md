---
date: 2026-04-26
status: active
tags: [infra, memory, multi-project]
---

# SecondBrain lives outside any single project

**Decision.** SecondBrain's canonical home is `~/SecondBrain`. Each project that uses it carries a symlink (`<project>/SecondBrain → ~/SecondBrain`).

**Reason.** Knowledge lifecycle ≠ project lifecycle. Projects archive, deprecate, get deleted; accumulated decisions/errors/learnings should outlive any of them. Co-locating the brain inside a project couples its survival to that project's fate and creates blast-radius risk.

**Trade-off.** Slightly more setup on a fresh clone (run `scripts/bootstrap.sh` to recreate the symlink). Tools that scan `cwd` still see the vault at the same relative path, so no functional regression. Sync/backup of the brain is now independent of any project's git remote.

**Revisit-if.**
- We move to a system where the OS-level symlink isn't transparent (e.g., a sandboxed filesystem).
- We adopt Obsidian Sync or similar and want the vault to live in that tool's preferred path.
- We end up with only one long-lived project (then nesting may simplify things again).
