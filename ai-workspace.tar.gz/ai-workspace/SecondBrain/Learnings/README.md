# Learnings

Mistakes made, lessons learned, and things you'd do differently.

This is your compound knowledge base — the things that don't make it into code or decisions but shape how you work.

## Format
```markdown
# [Learning — Short Title]
**Date**: YYYY-MM-DD
**Context**: [what project or situation]

## What Happened
[brief description]

## What I Learned
[the insight]

## How I'll Apply It
[concrete change to behavior or process]
```
