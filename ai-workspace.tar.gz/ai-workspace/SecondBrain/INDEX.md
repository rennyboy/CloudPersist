# SecondBrain — Top-Level Index

> Single brain across all projects. Lives at `~/SecondBrain`. Symlinked from `ai-workspace/SecondBrain` for path stability.
>
> **How it gets smarter:** see [`_meta/evolution-loop.md`](./_meta/evolution-loop.md). Short version — capture errors, surface them next session, promote recurring ones into rules.

## Always-loaded surfaces (read these at session start)

- [`Errors/INDEX.md`](./Errors/INDEX.md) — failure library: symptom → fix
- [`Knowledge/INDEX.md`](./Knowledge/INDEX.md) — distilled rules
- [`Decisions/INDEX.md`](./Decisions/INDEX.md) — major architectural calls
- [`Projects/INDEX.md`](./Projects/INDEX.md) — registry of projects this brain serves

## On-demand sections

- `Bugs/` — open investigations (graduate to Errors when resolved)
- `Learnings/` — raw observations (staging for Knowledge promotion)
- `Daily Notes/` — chronological archive
- `Templates/` — capture forms for new entries
- `Prompts/` — bootstrap and protocol prompts
- `Assistant/` — agent runtime state (schedule, reminders, inbox)

## Meta

- [`_meta/evolution-loop.md`](./_meta/evolution-loop.md) — design doc
- [`_meta/promotion-rules.md`](./_meta/promotion-rules.md) — when raw becomes Knowledge
- [`_meta/evolution-log.md`](./_meta/evolution-log.md) — changelog of the brain itself

## Token budget

Total always-loaded surface (this file + 4 INDEX files) capped at ~500 lines combined. Individual entries loaded only when their index line matches the current task.
