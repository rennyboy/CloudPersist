---
slug: <project-slug>
path: <absolute-path>
stack: []
status: active  # active | paused | archived
created: YYYY-MM-DD
last-touched: YYYY-MM-DD
---

# <Project Name>

## Goal
One sentence — what this project is trying to be.

## Stack
Languages, frameworks, runtime versions, key services.

## Links
- Handoff: `<path>/.ai/handoff.md`
- Memory: `<path>/.ai/memory.md`
- Tasks: `<path>/.ai/tasks.md`
- Repo: <url, if any>

## Cross-project notes
Anything about how this project relates to others (shared library, shared deploy target, common owner, etc.).

## Recent decisions
Pointers to entries in `Decisions/` that primarily affect this project.
