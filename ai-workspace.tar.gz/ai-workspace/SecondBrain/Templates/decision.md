---
date: YYYY-MM-DD
status: active  # active | superseded | reverted | expired
tags: []
---

# <one-line decision>

**Decision.** What was decided, in prescriptive form.

**Reason.** Why — the constraint, deadline, or insight that drove it.

**Trade-off.** What you're giving up by choosing this.

**Revisit-if.** The trigger condition under which this should be re-evaluated. Be concrete (a tool change, a scale threshold, a date).

---

**Don't forget:** add a row to `Decisions/INDEX.md`.
