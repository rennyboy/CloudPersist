# Templates

The canonical templates for scaffolding a new project (`.ai/memory.md`, `.ai/handoff.md`, `.ai/tasks.md`, role files, AGENTS.md, ignore files) live in **`.template/`** at the workspace root.

`new-project.sh <target-path>` copies `.template/` and fills in the project name and date.

Vault-side note templates (decision, daily note, learning, etc.) can be added here as they're needed. Do **not** duplicate the `.ai/` templates — `.template/` is the single source.
