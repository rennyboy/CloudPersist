---
date: YYYY-MM-DD
slug: <short-kebab-slug>
source: <project-slug or "general">
confidence: low  # low | medium | high
applied-times: 0
tags: []
---

# <one-line claim>

## Observation
What you noticed. Be specific — a fact, not a vibe.

## Why it might matter
The downstream consequence if true.

## Evidence so far
- Where you saw it (project, file, link)
- How many times

## To promote to Knowledge
Needs: applied successfully ≥1 more time, or confirmed by user, or seen in 2+ projects. See `_meta/promotion-rules.md`.

---

**Don't forget:** Learnings live in `Learnings/`. They are the staging area for `Knowledge/`. They do not need to appear in any always-loaded INDEX — they surface when the loop promotes them.
