---
date: YYYY-MM-DD
slug: <short-kebab-slug>
hits: 1
affects: [<project-slug>]
tags: []
status: open  # open | workaround | resolved | superseded
revisit-if: ""
---

# <one-line symptom>

## Symptom
What you saw — error message excerpt, stack trace head, observed behavior. Keep verbatim where possible (greppable).

## Context
- Stack / version / OS at the time
- What you were trying to do
- What you'd just changed (if known)

## Root cause
The actual reason — not the surface message.

## Fix
Concrete steps that resolved it. Code snippets if short. Links to longer fixes.

## Prevention
What you'll change so this doesn't recur. Examples: a config default, a lint rule, a Knowledge rule to promote, a CI check.

## Recurrence log
- YYYY-MM-DD — hit again in `<project>` — [link or note]

---

**Don't forget:** add a row to `Errors/INDEX.md` with the symptom excerpt → this file.
