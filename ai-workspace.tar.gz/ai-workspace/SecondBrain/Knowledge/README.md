# Knowledge

Technical concepts, references, and research notes.

One note per concept. Keep notes atomic — one idea per file.
Link related notes using `[[Note Name]]` Obsidian syntax.

Suggested naming: `[Topic] — [Specific Concept].md`
Example: `Laravel — Multi-tenancy Strategies.md`
