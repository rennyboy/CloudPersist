# Implementation Spec: Multi-AI Persistent Memory + Agent Workflow

## Objective

Build a model-agnostic persistent memory system that works across:

- Cursor
- Antigravity
- Kilo AI
- OpenCode
- GPT
- Claude
- future tools

Goal: eliminate repeated prompting, preserve context, enable seamless handoff between models.

---

## Core Architecture

Use two memory layers:

### 1. Repo Memory (Execution Layer)

Inside every project:

```text
Project/
├── .ai/
│   ├── memory.md
│   ├── handoff.md
│   ├── tasks.md
│   ├── decisions.md
│   ├── coding_rules.md
│   └── architecture.md

Purpose:

current project state
coding context
technical rules
next tasks
handoff between sessions
2. Vault Memory (Strategic Layer)

Use Obsidian or markdown vault outside repo.

Vault/
├── Projects/
├── Knowledge/
├── Systems/
├── Daily Notes/
├── Ideas/
├── Finance/
└── Templates/

Purpose:

product vision
business strategy
long-term learning
reusable prompts
founder operating system
Required File Definitions
.ai/memory.md

Store:

project name
stack
purpose
priorities
constraints
.ai/handoff.md

Store:

what was completed
current blockers
immediate next actions
.ai/tasks.md

Store:

sprint tasks
backlog
priorities
.ai/decisions.md

Store dated technical decisions.

.ai/coding_rules.md

Store:

style rules
architecture preferences
conventions
.ai/architecture.md

Store modules, services, data flow.

Agent Layer

Create reusable role prompts.

Project/
├── .agents/
│   ├── architect.md
│   ├── debugger.md
│   ├── refactor.md
│   ├── pm.md
│   └── reviewer.md
Standard Agent Behavior

Every agent must:

Read .ai/memory.md
Read .ai/handoff.md
Read relevant task/rules files
Perform assigned role
Preserve existing architecture
Write updates to .ai/handoff.md
If major decision made → append .ai/decisions.md
Example Agent Roles
architect.md

Focus:

system design
scalability
folder structure
database planning
debugger.md

Focus:

root cause analysis
minimal fixes
logs/errors review
refactor.md

Focus:

clean code
readability
maintainability
pm.md

Focus:

prioritize tasks
milestone planning
execution roadmap
reviewer.md

Focus:

code quality
standards compliance
risk detection
Standard Prompt for Any AI Tool
Read .ai folder first.
Use requested agent role.
Preserve project standards.
Continue from handoff.md.
Update handoff after task.
Daily Operating Workflow
Start Session

AI reads .ai/*

During Session

AI performs tasks using selected role.

End Session

Update:

handoff.md
tasks.md if needed
decisions.md if needed
Founder Side

Update vault notes for strategy/business insights.

Why This System Works
model independent
survives chat resets
portable across IDEs
low token usage
compounds knowledge
scales with multiple AI tools
future proof
Key Principle

Without memory:

AI = smart but forgetful

Without agents:

Memory = unused notebook

Together:

Persistent AI teammate

Final Formula
Repo Memory + Strategic Vault + Agent Roles + Best Available Model
= Elite Solo Builder System
