# AI Agent Context Summary: Claude Code Pro Token-Saving + Persistent Memory Setup

## User Goal
Maximize Claude Code Pro usage without hitting limits by reducing token waste and creating a persistent memory system usable across tools/models.

## Core Strategy
Treat Claude as a **stateless high-value reasoning/coding engine**, not long-term memory.

- Claude = architecture, deep coding, debugging, feature generation
- External memory = persistent context
- Cheap/local models = minor edits, autocomplete, small fixes
- Git = source of truth

## Recommended Stack

### Persistent Memory
Use **Obsidian Vault** as long-term memory.

Suggested vault:

AI-Workspace/
- Projects/
- Knowledge/
- Prompts/
- Decisions/
- Bugs/
- Learnings/

### Per Project Files
Inside each codebase:

- CLAUDE.md
- TODO.md
- ARCHITECTURE.md
- DECISIONS.md

## File Purposes

### CLAUDE.md
Minimal persistent context:

- project name
- stack
- coding rules
- architecture summary
- preferences

### TODO.md
Current active tasks only.

### ARCHITECTURE.md
System structure, modules, flows.

### DECISIONS.md
Why choices were made.

## Token Saving Principles

### Avoid:
Repeatedly re-explaining project context in chat.

### Prefer:
Load concise markdown context files.

Example prompt:

Read CLAUDE.md and TODO.md.
Task: Build authentication module.
Return step-by-step implementation only.

### Better Workflow:
One scoped large request > many fragmented small chats.

### Start New Chats Often
Avoid bloated long threads.

## Best Tool Division

### Claude Code Pro
Use for:

- hard debugging
- system design
- full features
- refactors requiring reasoning
- architecture

### Cursor / Kilo / Other Cheap Models
Use for:

- syntax fixes
- boilerplate edits
- autocomplete
- tiny refactors
- linting

## Elite Usage Pattern

Use Claude as stateless worker:

Load only relevant context each time.

Example:

Read architecture.md API section only.
Design payroll endpoints.

## Recommended Daily Routine

1. Update TODO.md
2. Update CLAUDE.md weekly
3. Store learnings in Obsidian
4. Use Claude only for high-value tasks
5. Use cheap models for small edits
6. Use fresh chats frequently

## Philosophy

Power users do NOT use Claude as memory.
They use Claude as a consultant/senior engineer.

## User Relevant Note
User likely building Laravel / SaaS / ERP / HRMIS style projects and benefits strongly from this structured memory workflow.
