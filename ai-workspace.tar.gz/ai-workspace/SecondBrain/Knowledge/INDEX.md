# Knowledge INDEX — Distilled Rules

> Always-loaded at session start. Stable rules promoted from repeated Errors and confirmed Learnings.
>
> Cap: 100 lines. Each entry is prescriptive — "when X, do Y, because Z."

## Entries

| Topic | Rule (one-line summary) | File | Promoted from |
|---|---|---|---|

<!-- Example row:
| npm peer deps | After Node 20+, use `--legacy-peer-deps` until packages catch up | [npm-peer-deps.md](./npm-peer-deps.md) | 4 errors across 2 projects |
-->

_(empty — populate via promotion from Errors/Learnings; see `_meta/promotion-rules.md`)_

---

## Archive

Older Knowledge files (predecessors of current rules) live in `archive/`. They are kept for context but not in this index.

- [archive/InstructionsPersistentMemory.md](./archive/InstructionsPersistentMemory.md)
- [archive/TokenSaving.md](./archive/TokenSaving.md)
- [archive/claudePersistentMemory.md](./archive/claudePersistentMemory.md)
