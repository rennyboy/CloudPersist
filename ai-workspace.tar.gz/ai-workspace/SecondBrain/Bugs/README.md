# Bugs

Recurring bug patterns, root causes, and their resolutions.

Save bugs here when the same class of issue has appeared more than once — so you recognize it faster next time.

## Format
```markdown
# [Bug Name / Pattern]
**Seen in**: [project(s)]
**Stack**: [relevant tech]

## Symptom
[what it looks like on the surface]

## Root Cause
[actual underlying cause]

## Fix
[minimal fix or workaround]

## How to Prevent
[convention or rule to add to coding_rules.md]
```
