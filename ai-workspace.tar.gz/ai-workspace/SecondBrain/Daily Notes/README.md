# Daily Notes

Per-session or per-day reflections and quick captures.

Naming convention: `YYYY-MM-DD Daily.md`
Example: `2026-04-24 Daily.md`

## What to Capture
- What you worked on
- What got stuck
- Quick ideas to revisit
- Links to relevant files updated

## Keep It Short
Daily notes are input — not output. They feed into Learnings, Decisions, and Prompts over time. Don't over-engineer them.
