# Assistant — Daily State

Living files the personal assistant agents (`.agents/assistant.md`, `scheduler.md`, `reminder.md`) read and write every day.

## Files
| File | Owner role | Purpose |
|---|---|---|
| `schedule.md` | `scheduler` | Today's time-blocks + forward week |
| `reminders.md` | `reminder` | Active reminders with due dates + recurrence |
| `inbox.md` | `assistant` | Raw capture — triaged into schedule/reminders/projects |

Daily notes live in `SecondBrain/Daily Notes/YYYY-MM-DD.md` — the assistant appends to today's file after each interaction.

## Daily rhythm
- **Morning**: `assistant` reads all three files + today's daily note → 5-line briefing.
- **Mid-day**: `scheduler` adjusts blocks if the plan slips.
- **Evening**: `assistant` wraps — marks completed blocks, resolves reminders, processes inbox, logs daily note.

## Rules
- Every change to these files gets a one-line entry in the day's daily note.
- Keep `inbox.md` to <30 items — if it grows, do a triage pass.
- Keep `reminders.md` to <50 items — if older overdue items pile up, run the weekly accountability pass.
