# Schedule

Owner role: `scheduler`. Format defined in `.agents/scheduler.md`.

## 2026-04-24
- 08:00–08:30 [shallow] Morning check-in + inbox triage
- 08:30–10:00 [deep] Apply framework-agnostic memory system to first real project (source: .ai/tasks.md Next Sprint)
- 10:00–10:15 Break
- 10:15–11:45 [deep] Populate SecondBrain/Prompts/ with 3 reusable prompts (source: .ai/tasks.md)
- 11:45–12:30 Lunch
- 12:30–13:30 [shallow] Weekly review — check SecondBrain/Learnings/ for patterns
- 13:30–15:00 [deep] Open slot (assign from inbox at 08:00 check-in)
- 15:00–15:15 Break
- 15:15–16:45 [deep] Open slot
- 16:45–17:30 [shallow] Evening wrap — update handoff.md + daily note

Notes: Two deep-work blocks protected AM, two PM. Assign open afternoon blocks during morning check-in based on energy + inbox.

## This Week
- Mon 2026-04-27 — first real project template application
- Tue 2026-04-28 — agent role real-usage test
- Wed 2026-04-29 — SecondBrain/Prompts fill-out
- Thu 2026-04-30 — git init workspace
- Fri 2026-05-01 — weekly review

## Conventions
- `[deep]` = focus work, no interruptions, phone silent
- `[shallow]` = email, triage, meetings, admin
- Blocks without a source line are off-protocol — the scheduler must cite a file for every committed block
