# Reminders

Owner role: `reminder`. Format defined in `.agents/reminder.md`.

Entry format:
```
- [ ] <what> | due: YYYY-MM-DD [HH:MM] | recur: none|daily|weekly|monthly | created: YYYY-MM-DD | context: <one line>
```

## Active
- [ ] Apply .ai/ template to first real project | due: 2026-04-27 | recur: none | created: 2026-04-24 | context: next-sprint task from .ai/tasks.md
- [ ] Populate SecondBrain/Prompts/ with 3 reusable prompts | due: 2026-04-29 | recur: none | created: 2026-04-24 | context: next-sprint task
- [ ] Weekly review | due: 2026-05-01 | recur: weekly | created: 2026-04-24 | context: Friday review of Daily Notes + stale reminders
- [ ] Run `git init` on workspace | due: 2026-04-30 | recur: none | created: 2026-04-24 | context: backlog item — version control the system itself

## Completed (archive monthly)
<!-- Move completed reminders here on completion. Clear at end of month. -->

## Conventions
- Overdue items stay in Active until resolved — never silently dropped.
- Recurring items: on completion, update `due:` to next occurrence; do not create a new row.
- Context line must answer "why does this matter?" in one line — if you can't, the reminder is noise.
