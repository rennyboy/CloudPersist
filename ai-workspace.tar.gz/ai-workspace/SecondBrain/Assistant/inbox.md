# Inbox

Owner role: `assistant`. Raw capture — triaged into schedule, reminders, project tasks, or dropped.

## New (untriaged)
<!-- Dump anything here, fast. One line per item. Timestamp optional. -->
- [2026-04-24] Test AGENTS.md bootstrap in a non-Claude tool (Cursor or Kilo) to validate the pointer pattern actually works end-to-end

## Triage rules
When processing this inbox:
1. **Actionable today?** → move to `schedule.md` as a block.
2. **Actionable by a date?** → move to `reminders.md` with a due date.
3. **Project work?** → move to that project's `.ai/tasks.md`.
4. **Idea / reference?** → move to `SecondBrain/Ideas/` or `SecondBrain/Knowledge/`.
5. **Noise?** → delete, no guilt.

Target: empty inbox end of each day. If >30 items pile up, run a dedicated triage block before anything else.
