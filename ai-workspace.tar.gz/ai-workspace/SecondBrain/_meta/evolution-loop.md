# Evolution Loop — How SecondBrain Gets Smarter

> SecondBrain is not a file dump. It is a feedback loop. Every error becomes a search hit; every recurrence triggers a rule; every rule trims future tokens.

## The five-stage loop

```
   ┌────────────────────────────────────────────────────────────┐
   │                                                            │
   ▼                                                            │
[1 ENCOUNTER]  error / surprise / decision happens in a project │
   │                                                            │
   ▼                                                            │
[2 CAPTURE]    write to Errors/<date>-<slug>.md                 │
                add 1 line to Errors/INDEX.md                   │
   │                                                            │
   ▼                                                            │
[3 RECALL]     next session → Errors/INDEX.md is auto-loaded    │
                AI recognizes symptom before re-failing          │
   │                                                            │
   ▼                                                            │
[4 PROMOTE]    seen ≥3× or in ≥2 projects → distill into        │
                Knowledge/<topic>.md as a stable rule           │
                remove individual entries, log promotion         │
   │                                                            │
   ▼                                                            │
[5 DECAY]      monthly review: stale entries archived to        │
                Daily Notes/YYYY-MM-DD.md (history, not memory) │
   │                                                            │
   └────────────────────────────────────────────────────────────┘
```

## Why this is "fine-tuning without fine-tuning"

You can't actually fine-tune a frontier model. But you *can* make every session start with a small, dense, project-aware context that includes "things you tried before and how they failed." That's behaviorally equivalent for the 80% case.

Three forces compound:

1. **Recall pressure** — `Errors/INDEX.md` is loaded every session. As it grows, the AI's "world model" of your stack grows with it. Bounded by the index file size cap (200 lines, ~6KB).
2. **Promotion pressure** — repeated entries get distilled into Knowledge rules, which are denser per token. 10 individual `npm ENOENT` errors → 1 Knowledge entry: "Use --legacy-peer-deps after Node 20 upgrade".
3. **Decay pressure** — stale errors leave the index. The vault's *active* surface stays small even as its *archive* grows.

## The cardinal rule: **the index is the brain**

A file in `Errors/` that isn't in `Errors/INDEX.md` does not exist for the loop. Every capture **must** add an index line. Templates enforce this.

## Multi-project shape

```
~/SecondBrain/                        ← single brain
  Projects/
    myApp.md                          ← registry entry per project
    projectX.md                       ← path, stack, status, last-touched
    INDEX.md                          ← roster
  Errors/                             ← cross-project failure library
    INDEX.md                          ← always-loaded
    2026-04-26-npm-peer-dep.md
    ...
  Knowledge/                          ← cross-project distilled rules
  Decisions/                          ← cross-project major decisions
  Daily Notes/                        ← cross-project chronological
```

Per-project state (`.ai/handoff.md`, `.ai/memory.md`, `.ai/tasks.md`) stays inside each project. SecondBrain holds **what generalizes across projects.**

## Promotion criteria (cheap and inspectable)

| Source | Signal | Destination |
|---|---|---|
| `Errors/<file>.md` | seen ≥3× across sessions | `Knowledge/<topic>.md` rule |
| `Errors/<file>.md` | seen in ≥2 different projects | `Knowledge/<topic>.md` rule |
| `Learnings/<file>.md` | confirmed by user / used twice | `Knowledge/<topic>.md` |
| `Bugs/<file>.md` | resolved | `Errors/<file>.md` (with fix) |
| `Knowledge/<topic>.md` | superseded | `Daily Notes/YYYY-MM-DD.md` (archive) |

See `promotion-rules.md` for the operational checklist.

## Anti-patterns the loop is built to prevent

- **Chat-only learnings** — a fix discussed in chat is lost. Capture or it didn't happen.
- **Index drift** — files added but not indexed. Index reviews catch this monthly.
- **Distillation never happens** — every Friday (or session-end #N), run `Prompts/promotion-review.md`.
- **The vault becomes a graveyard** — decay rules force pruning. If the loop stalls, the brain rots.

## Token budget invariants

| File | Cap | Why |
|---|---|---|
| `INDEX.md` (top-level) | 50 lines | Always loaded |
| `Errors/INDEX.md` | 200 lines | Always loaded — fastest growth |
| `Knowledge/INDEX.md` | 100 lines | Always loaded |
| `Decisions/INDEX.md` | 100 lines | Always loaded |
| `Projects/INDEX.md` | 50 lines | Always loaded — one row per project |
| Individual entry files | 50 lines | Loaded only on demand |

When a cap is hit → split, archive, or distill. Never bypass.
