# Evolution Log

Append-only log of changes to the brain itself: promotions, demotions, structural changes, capacity events. One line per event.

Format: `YYYY-MM-DD | <event> | <details>`

---

2026-04-26 | structure-init | Evolution-loop scaffolding created. Indexes for Errors, Knowledge, Decisions, Projects. Templates for capture. Promotion rules established.
2026-04-26 | move | SecondBrain relocated from `ai-workspace/SecondBrain` to `~/SecondBrain` (symlink left behind for path stability).
