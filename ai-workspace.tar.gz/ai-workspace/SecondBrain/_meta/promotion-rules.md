# Promotion Rules — When Raw Becomes Distilled

The loop only "evolves" if you *promote*. These rules tell you (and any AI agent acting on your behalf) when an entry is ready to graduate.

## Triggers (any one is enough)

### Errors → Knowledge
- The error was hit **3+ times** across sessions (counter in the entry's frontmatter).
- The error was hit in **2+ different projects** (`affects:` list in frontmatter).
- The fix is a **stable workaround** that's outlived 1+ tool/version upgrade.

### Learnings → Knowledge
- The same observation appears in 2+ Learning files.
- The user explicitly confirmed: *"yes, that's a real rule, save it."*
- The learning has been *applied successfully* in a follow-up session.

### Bugs → Errors
- Bug is **resolved** (root cause + fix known).
- Even partial: capture as Error with `status: workaround` and a `revisit-if:` line.

### Knowledge → Daily Notes (archival)
- The rule is **superseded** by a newer Knowledge entry.
- The underlying tool/library was removed.
- Reviewed twice consecutively as "no longer applies."

## Promotion checklist (per item)

1. Open the source entry. Check trigger above is satisfied.
2. Open or create the target Knowledge file: `Knowledge/<topic>.md`.
3. Write the rule in **prescriptive form**: "When X, do Y. Why: Z."
4. Add 1 line to `Knowledge/INDEX.md`.
5. Remove (or archive) the source entries:
   - If 1 source: delete it (it now lives as Knowledge).
   - If many sources: delete each, leave a comment in `_meta/evolution-log.md`.
6. Remove their lines from the source `INDEX.md`.
7. Append a row to `_meta/evolution-log.md`: date, what was promoted, source count.

## Cadence

| Cycle | Trigger | What |
|---|---|---|
| Per session | Error captured | If counter hits 3 → flag for promotion next review |
| Weekly | Friday or session #N | Review `Errors/INDEX.md` for flagged items |
| Monthly | First of month | Walk all four INDEX files; archive stale, promote ripe |
| Quarterly | Every 3 months | Re-read top-level INDEX; restructure if folders feel wrong |

## The "is it really a rule?" test

Before promoting to Knowledge, ask:
- Will this still apply in 6 months? (If not → keep as Error/Learning.)
- Does it generalize beyond one project? (If not → keep in project's `.ai/memory.md`.)
- Can I state it in 3 lines or fewer? (If not → it's not a rule yet, it's a tutorial.)

If all three: promote.

## What never gets promoted

- Project-specific config values (URLs, IDs, account names) — those live in the project's `.ai/memory.md`.
- Personal preferences ("I like tabs") — those live in your global Claude memory, not SecondBrain.
- One-off incidents with no transferable lesson.

## Demotion (rare but real)

If a promoted Knowledge rule turns out to be wrong:
1. Don't delete silently. Move it to `Daily Notes/YYYY-MM-DD.md` with a `# Reverted` header and a one-line reason.
2. Add a new entry to `Errors/` capturing what made it wrong (so the loop learns from its own mistake).
3. Log in `_meta/evolution-log.md`.
