# TODO — Current Sprint

> Keep this file sprint-scoped. Completed items move to `.ai/tasks.md`.

## Active
- [ ] Apply `.ai/` template to your first real project
- [ ] Add 3-5 reusable prompts to `SecondBrain/Prompts/`
- [ ] Test each agent role prompt in a real session
- [ ] Create a daily note in `SecondBrain/Daily Notes/` using the template

## Done This Sprint
- [x] Design and implement the AI Workspace persistent memory system
- [x] Create CLAUDE.md, .ai/, .agents/, SecondBrain/, .claude/rules/
