#!/usr/bin/env bash
# new-project.sh — scaffold a new project with the AI workspace protocol.
# Usage: bash new-project.sh <target-path>

set -euo pipefail

if [[ $# -ne 1 ]]; then
  echo "Usage: $0 <target-path>" >&2
  exit 1
fi

TARGET="$1"
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
TEMPLATE="$SCRIPT_DIR/.template"

if [[ ! -d "$TEMPLATE" ]]; then
  echo "Template folder missing: $TEMPLATE" >&2
  exit 1
fi

if [[ -e "$TARGET" && -n "$(ls -A "$TARGET" 2>/dev/null || true)" ]]; then
  echo "Target exists and is not empty: $TARGET" >&2
  exit 1
fi

mkdir -p "$TARGET"
cp -r "$TEMPLATE/." "$TARGET/"

NAME="$(basename "$(cd "$TARGET" && pwd)")"
TODAY="$(date +%Y-%m-%d)"
sed -i "s/\[Project Name\]/$NAME/" "$TARGET/.ai/memory.md"
sed -i "s/\[YYYY-MM-DD\]/$TODAY/" "$TARGET/.ai/memory.md"
sed -i "s/\[YYYY-MM-DD\]/$TODAY/" "$TARGET/.ai/handoff.md"

# Link the shared brain so this project participates in the cross-project evolution loop.
BRAIN="${SECONDBRAIN_HOME:-$HOME/SecondBrain}"
if [[ -d "$BRAIN" ]]; then
  ln -s "$BRAIN" "$TARGET/SecondBrain"
  echo "Linked SecondBrain: $TARGET/SecondBrain -> $BRAIN"
  ROSTER="$BRAIN/Projects/INDEX.md"
  if [[ -f "$ROSTER" ]] && ! grep -q "| $NAME |" "$ROSTER"; then
    ABSPATH="$(cd "$TARGET" && pwd)"
    awk -v row="| $NAME | \`$ABSPATH\` | (TBD) | $TODAY | active |" \
      '/^## Archived/ && !done {print row; done=1} {print}' "$ROSTER" > "$ROSTER.tmp" \
      && mv "$ROSTER.tmp" "$ROSTER"
    echo "Registered $NAME in $ROSTER"
  fi
else
  echo "WARN: $BRAIN not found — skipped SecondBrain symlink. Run scripts/bootstrap.sh later."
fi

if [[ -x "$SCRIPT_DIR/scripts/check-drift.sh" ]]; then
  echo "Running drift check on workspace..."
  "$SCRIPT_DIR/scripts/check-drift.sh" || echo "(drift check reported issues — resolve in the workspace, scaffold is unaffected)"
fi

cat <<EOF
Scaffold created at $TARGET
Next:
  1. cd "$TARGET" && fill in .ai/memory.md (Purpose, Stack, Priorities)
  2. Open your AI tool and say: "Use the architect role. Design the initial structure."
EOF
