# USAGE.md — How to Actually Use This Workspace

Practical day-to-day workflow. Scannable. See `AGENTS.md` for the full protocol and `ARCHITECTURE.md` for system layout.

---

## 0. Quick Mental Model

```
AI tool           → reads a pointer file (CLAUDE.md / .cursorrules / etc)
pointer file      → points at AGENTS.md
AGENTS.md         → tells the tool to read .ai/handoff.md + .ai/memory.md[section] + maybe a role
role file         → tells the tool how to behave for that task
state lives on disk — not in chat
```

You activate a role by saying one sentence: **"Use the `<role>` role."**

---

## 1. New Project (one-time, ~5 min)

```
1. bash /path/to/ai-workspace/new-project.sh /path/to/newproj
       └─ copies .template/ → new project, stamps [Project Name] + [YYYY-MM-DD]
       └─ runs scripts/check-drift.sh on the workspace

2. cd /path/to/newproj
       open in your AI tool of choice

3. Fill in .ai/memory.md — 3 sections only:
       • Purpose (1-2 lines: what this project is)
       • Stack (bullets: Laravel 11, MySQL, Redis, etc.)
       • Priorities (top 3, numbered)
       Leave Constraints / Context empty until they matter.

4. Prompt: "Use the architect role. Design the initial structure based on
            .ai/memory.md Purpose + Stack. Output a 15-line directory plan."

5. Commit the scaffold:
       git init && git add .ai .agents AGENTS.md CLAUDE.md \
           .cursorrules .windsurfrules .kilocode .cursor .claude \
       && git commit -m "scaffold: AI workspace protocol"
```

The `.template/` is the single source of truth for scaffolding — do not copy files manually.

---

## 2. Daily Rhythm (Personal Assistant)

### Morning (5 min)
Open any AI tool. Say:

> Use the assistant role. Morning check-in.

The assistant will:
1. Read `SecondBrain/Assistant/schedule.md`, `reminders.md`, `inbox.md`
2. Return a 5-line briefing: today's blocks, due reminders, top 3 inbox items
3. Ask which open afternoon blocks you want to assign

### During the day
- **Capture anything, anywhere**: *"Add to inbox: <thing>"* → assistant writes one line to `inbox.md`
- **Plan changes**: *"Use the scheduler role. I lost my 10:15 block to a meeting — reschedule."*
- **Set a reminder**: *"Use the reminder role. Remind me to email Alex about the contract by Thursday."*

### Evening (5 min)
> Use the assistant role. Evening wrap.

The assistant will:
1. Ask what got done
2. Mark completed blocks in `schedule.md`, resolve/reschedule reminders
3. Process inbox (triage new items → schedule / reminders / projects / drop)
4. Append a one-line entry to `SecondBrain/Daily Notes/YYYY-MM-DD.md`

### Weekly (Friday, 15 min)
> Use the assistant role. Weekly review. Scan all .ai/handoff.md across active projects.
> Surface: recurring blockers, decisions worth promoting to SecondBrain/Decisions/,
> patterns worth promoting to SecondBrain/Prompts/ or Learnings/.

Then a reminder-role pass:
> Use the reminder role. Weekly accountability pass.

Surfaces: overdue >7d, recurring items missed >50% of the time. Propose changes, you approve.

### Monthly maintenance (2 min)
```
bash scripts/check-drift.sh
```
Catches `.ai/*` size violations, missing mirror labels, indexer drift. Rotate per `AGENTS.md §2` when it warns.

---

## 3. Coding Session Workflow

### Start a coding session
Open the AI tool inside the project folder (not this workspace). The project's `AGENTS.md` / `CLAUDE.md` auto-loads. Then:

> Use the <role> role. Task: <what you want built>.

The agent reads `.ai/handoff.md` + the relevant section of `.ai/memory.md`, loads the role, and waits.

### Pick the right role (one per session — never mix)
| Role | When to use |
|---|---|
| `architect` | New feature, new module, database design, folder structure |
| `debugger` | Bug, unexpected error, test failure — minimal fix |
| `refactor` | Code works but is ugly — clean up, no behavior change |
| `pm` | Sprint planning, task breakdown, milestone ordering |
| `reviewer` | PR review, code quality, risk detection before ship |

### End a coding session
> Wrap up. Update handoff.md and tasks.md.

Or the agent does it automatically per the protocol in `AGENTS.md`.

### Don't do this
- Don't paste `.ai/memory.md` content into chat. Reference it: *"Read .ai/memory.md Stack section."*
- Don't run one long thread across multiple tasks. One task = one fresh chat.
- Don't mix roles. If the debugger finds an architecture problem, wrap the debug session and start an architect session.

---

## 4. When Which AI

| Task | Tool | Reason |
|---|---|---|
| Architecture, hard debug, design | Claude Code / Opus | High-value reasoning |
| Boilerplate, syntax, autocomplete | Cursor tab / Kilo | Cheap, fast |
| Off-machine / phone | GPT/ChatGPT + paste `SecondBrain/Prompts/bootstrap.md` | Manual, same protocol |
| Long-form refactor review | `reviewer` role in Claude Code | Role prepends session protocol |
| Quick syntax fix | Local model / Cursor tab | Don't burn API credits |

---

## 5. Cross-Tool Use (same workflow, different tool)

### Claude Code
Just start. `CLAUDE.md` auto-loads → points to `AGENTS.md`. `.claude/rules/*.md` auto-load as enforcement mirrors.

### Cursor
`.cursor/rules/main.mdc` auto-loads (native format) → points to `AGENTS.md`. `.cursorrules` also honored as legacy.

### Windsurf
`.windsurfrules` auto-loads. Same pattern.

### Kilo AI
`.kilocode/rules.md` auto-loads. Same pattern. `.kilocodeignore` trims build output; `SecondBrain/` stays searchable.

### Zed / Antigravity / OpenCode
These read `AGENTS.md` natively. Just start.

### ChatGPT / GPT-5 / generic Codex (no auto-load)
Paste `SecondBrain/Prompts/bootstrap.md` as your first message. Pick the coding variant or the personal-assistant variant. Then give your task.

### Gemini Code Assist
`.aiexclude` respected. Manual bootstrap via the same prompt file.

---

## 6. Common Recipes

### "I'm starting a new project"
See §1 above — always use `new-project.sh`. Never copy files manually; the template is the single source.

### "I had a great idea at 11pm"
> Use the assistant role. Add to inbox: <idea>.

One line, done. Triage tomorrow morning.

### "I'm getting too many reminders"
> Use the reminder role. Weekly accountability pass. Be ruthless.

It'll surface items you're silently dropping and propose to kill them.

### "I don't know what to work on"
> Use the assistant role. Briefing — what's most important right now?

Pulls from `schedule.md`, `reminders.md`, `inbox.md`, and any active project's `.ai/tasks.md`.

### "The AI is hallucinating context"
Two causes:
1. It didn't actually read the files. Say: *"Confirm you read `.ai/handoff.md`. Paste the first line."*
2. The file is stale. Open it, check the date, update it.

### "I'm switching tools mid-task"
End the current session (update handoff). Open the other tool. Say *"Use the `<same-role>` role. Continue from handoff."* Works because state is on disk.

### "A pointer file drifted and started accumulating rules"
Run `bash scripts/check-drift.sh`. It will flag any pointer file that lost its reference to `AGENTS.md`. Trim the pointer back to one sentence.

### "handoff.md is over 25 lines"
Apply the rotation rule (`AGENTS.md §2`): move the "What Was Completed" section to `SecondBrain/Daily Notes/YYYY-MM-DD.md`, leave only current-state in `handoff.md`.

---

## 7. Token-Saving Checklist

Enforce these — they compound:

- [ ] Scoped reads only: *"Read `.ai/memory.md` Stack section"* not *"Read `.ai/memory.md`"*
- [ ] One task per session. Fresh chat for unrelated work.
- [ ] Never re-paste project context in chat. Reference it.
- [ ] Use cheap tools (Cursor tab, Kilo, local models) for syntax fixes, boilerplate, tiny edits.
- [ ] Reserve Claude Code Pro / Opus / GPT-5 for design, debugging, architecture.
- [ ] Keep `.ai/*` under 50 lines each. `handoff.md` under 25. Rotate (don't silently exceed).
- [ ] Indexer ignores exclude `.obsidian/` + build output only. `SecondBrain/` stays searchable so prompts/decisions/learnings are findable across tools.
- [ ] Run `scripts/check-drift.sh` monthly or before committing rule changes.

---

## 8. Troubleshooting

| Symptom | Fix |
|---|---|
| Tool ignores the rules file | Check the tool's docs for its rule filename. Add a pointer to `AGENTS.md` there. |
| "Loaded" confirmation is missing | Tool isn't following the protocol — paste `SecondBrain/Prompts/bootstrap.md` manually. |
| Schedule keeps drifting | You're not doing evening wrap. Block 5 min at end of day for it. |
| Inbox >30 items | Run a dedicated triage block. Drop aggressively. |
| Reminders pile up | Weekly accountability pass — kill what you're dropping, don't reschedule forever. |
| Rule drift between tools | Only `AGENTS.md` contains logic. `.claude/rules/*.md` are labeled mirrors. Everything else is a pointer. Run `scripts/check-drift.sh`. |
| `check-drift.sh` fails on handoff cap | Rotate per `AGENTS.md §2` — move old content to `SecondBrain/Daily Notes/YYYY-MM-DD.md`. |
| `.claude/rules/*` and `AGENTS.md` disagree | `AGENTS.md` wins. Edit it first, then re-sync the mirror header and body. |

---

## 9. Role Cheat Sheet

Activate by saying the phrase verbatim:

```
"Use the architect role."   → design, structure, data flow
"Use the debugger role."    → root cause, minimal fix
"Use the refactor role."    → readability, no behavior change
"Use the pm role."          → prioritize, plan milestone
"Use the reviewer role."    → risk, quality gate
"Use the assistant role."   → daily check-in, wrap, weekly review
"Use the scheduler role."   → time-blocking, calendar
"Use the reminder role."    → accountability, nags
```

---

## 10. What NOT to Put Here

- Code. This is a workflow workspace, not a codebase.
- Secrets. `.ai/` is plain text.
- Long-form prose. Every file has a purpose; prose goes in `SecondBrain/Knowledge/` or `Daily Notes/`.
- Duplicates. `AGENTS.md` is canonical. If a rule lives anywhere else (except labeled `.claude/rules/` mirrors), it will drift.

---

## 11. One-Line Principles

- **Claude / GPT / Cursor are consultants, not memory.**
- **State lives on disk, or it didn't happen.**
- **One task per session. One role per session.**
- **Scoped reads, not full loads.**
- **`AGENTS.md` wins every conflict.**
- **Rotate before you silently exceed a cap.**
