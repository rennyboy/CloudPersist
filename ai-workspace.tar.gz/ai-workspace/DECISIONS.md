# Decision Log

> Strategic and cross-project decisions. Per-project decisions go in `.ai/decisions.md`.

## 2026-04-24 — Chose markdown over database for memory storage
**Decision**: All memory is plain markdown files, not a database or structured API.
**Reason**: Zero setup, zero dependencies, works offline, readable by humans and all AI tools. Portability trumps query power at this scale.

## 2026-04-24 — Chose Obsidian as the vault tool
**Decision**: `SecondBrain/` is an Obsidian vault.
**Reason**: Already initialized (`.obsidian/` config existed). Obsidian is local-first, markdown-native, and has strong graph/linking features useful for knowledge management.
**Trade-off**: Vault content is machine-local until sync is configured. Obsidian-specific features (graph view, plugins) don't work in other editors.

## 2026-04-24 — Treat Claude as stateless high-value engine, not memory
**Decision**: Claude (and other AI tools) are workers, not memory stores. Memory lives in files.
**Reason**: AI sessions reset. Files don't. Separation of concerns: AI = reasoning, files = state.
**How to apply**: Always load `.ai/` context at session start; never rely on chat history as the source of truth.
