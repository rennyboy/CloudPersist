#!/usr/bin/env bash
# check-drift.sh — verify the AI workspace stays consistent.
# Exits non-zero on any violation. Run before committing or on-demand.

set -u
ROOT="$( cd "$( dirname "${BASH_SOURCE[0]}" )/.." && pwd )"
cd "$ROOT"

FAIL=0
warn() { echo "DRIFT: $1" >&2; FAIL=1; }
ok()   { echo "  ok  $1"; }

echo "Checking AI workspace drift in: $ROOT"

# 1. AGENTS.md must exist — it is the source of truth.
if [[ -f AGENTS.md ]]; then ok "AGENTS.md present"
else warn "AGENTS.md missing — this is the single source of truth"; fi

# 2. Every per-tool pointer must reference AGENTS.md.
for f in CLAUDE.md .cursorrules .windsurfrules .kilocode/rules.md .cursor/rules/main.mdc; do
  if [[ ! -f "$f" ]]; then
    warn "pointer file missing: $f"
  elif ! grep -q "AGENTS.md" "$f"; then
    warn "$f does not reference AGENTS.md"
  else
    ok "$f → AGENTS.md"
  fi
done

# 3. .claude/rules/*.md must declare themselves as mirrors of AGENTS.md.
for f in .claude/rules/memory-workflow.md .claude/rules/token-saving.md; do
  if [[ ! -f "$f" ]]; then
    warn "enforcement mirror missing: $f"
  elif ! grep -qi "mirror of .AGENTS.md" "$f"; then
    warn "$f is not labeled as a mirror of AGENTS.md (add '> Enforcement mirror of AGENTS.md ...' header)"
  else
    ok "$f labeled as AGENTS.md mirror"
  fi
done

# 4. .ai/ size caps.
cap() {
  local file=$1 limit=$2
  if [[ ! -f "$file" ]]; then
    ok "$file absent (optional)"; return
  fi
  local lines; lines=$(wc -l < "$file")
  if (( lines > limit )); then
    warn "$file is $lines lines (cap $limit) — rotate per AGENTS.md §2"
  else
    ok "$file $lines/$limit lines"
  fi
}
cap .ai/handoff.md       25
cap .ai/memory.md        80
cap .ai/tasks.md         50
cap .ai/decisions.md     50
cap .ai/architecture.md  80
cap .ai/coding_rules.md  50

# 5. SecondBrain/ should NOT be listed in any indexer ignore (the vault must stay searchable).
for f in .cursorignore .kilocodeignore .aiexclude .codeiumignore; do
  if [[ ! -f "$f" ]]; then continue; fi
  if grep -qE "^SecondBrain/?" "$f"; then
    warn "$f excludes SecondBrain/ — vault should stay indexed"
  else
    ok "$f keeps SecondBrain/ searchable"
  fi
done

# 6. PersistentGuides/ at root was archived — warn if re-created.
if [[ -d PersistentGuides ]]; then
  warn "PersistentGuides/ reappeared at root — it was archived to SecondBrain/Knowledge/archive/"
fi

echo
if (( FAIL )); then
  echo "check-drift.sh: FAILED"
  exit 1
fi
echo "check-drift.sh: OK"
