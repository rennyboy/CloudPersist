#!/usr/bin/env bash
# Ensures SecondBrain is reachable from this workspace.
# Canonical home: $HOME/SecondBrain (independent sync/backup).
# This script creates the symlink ai-workspace/SecondBrain -> ~/SecondBrain
# if it's missing, so a fresh clone is immediately usable.
#
# Idempotent. Safe to run any time.

set -euo pipefail

WORKSPACE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
LINK="$WORKSPACE_DIR/SecondBrain"
TARGET="${SECONDBRAIN_HOME:-$HOME/SecondBrain}"

if [ -L "$LINK" ]; then
  current="$(readlink "$LINK")"
  if [ "$current" = "$TARGET" ]; then
    echo "OK  symlink already points to $TARGET"
    exit 0
  fi
  echo "WARN symlink points to $current (expected $TARGET) — leaving as-is"
  exit 0
fi

if [ -d "$LINK" ] && [ ! -L "$LINK" ]; then
  echo "ERROR $LINK is a real directory. Refusing to clobber."
  echo "      Move it manually: mv \"$LINK\" \"$TARGET\" && ln -s \"$TARGET\" \"$LINK\""
  exit 1
fi

if [ ! -d "$TARGET" ]; then
  echo "INFO $TARGET does not exist; creating empty vault skeleton"
  mkdir -p "$TARGET"/{Projects,Knowledge,Errors,Decisions,Prompts,Learnings,Bugs,"Daily Notes",Templates,Assistant,_meta}
fi

ln -s "$TARGET" "$LINK"
echo "OK  created symlink: $LINK -> $TARGET"
