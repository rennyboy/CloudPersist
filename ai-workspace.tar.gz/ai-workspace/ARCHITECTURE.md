# Architecture — AI Workspace

## What This Is
A model-agnostic persistent memory and agent workflow system for solo AI-powered builders.

## The Problem It Solves
Every AI chat session starts blank. Without memory:
- You re-explain the project every time
- Context is lost between tools (Cursor → Claude → GPT)
- Decisions get forgotten and re-debated
- You can't hand off cleanly between sessions

## The Solution: Three Layers

### Layer 1: Repo Memory (`.ai/`)
Six markdown files in every project. Any AI tool reads them first.

| File | Purpose |
|---|---|
| `memory.md` | Project identity — name, stack, goals, constraints |
| `handoff.md` | Session state — what's done, blockers, next action |
| `tasks.md` | Sprint tasks and backlog |
| `decisions.md` | Dated log of why choices were made |
| `coding_rules.md` | Style, conventions, AI interaction rules |
| `architecture.md` | Module structure and data flow |

### Layer 2: Strategic Vault (`SecondBrain/`)
Obsidian vault for cross-project, long-term knowledge.

| Folder | Purpose |
|---|---|
| `Projects/` | High-level note per active project |
| `Knowledge/` | Technical concepts and research |
| `Prompts/` | Reusable AI prompt templates |
| `Decisions/` | Strategic decisions across projects |
| `Bugs/` | Recurring bug patterns and resolutions |
| `Learnings/` | Mistakes made and lessons learned |
| `Daily Notes/` | Per-session reflections |
| `Templates/` | Copy-paste starters for .ai/ and vault notes |

### Layer 3: Agent Roles (`.agents/`)
Role prompts that focus AI behavior per task type. Each agent reads `.ai/` first.

## How It All Connects

```
New session →
  Claude reads CLAUDE.md automatically
  You (or CLAUDE.md) instruct: "Read .ai/memory.md and .ai/handoff.md"
  Optional: "Use the architect role"
  
Work happens →
  Agent uses loaded context to perform the task
  
Session ends →
  .ai/handoff.md updated
  .ai/tasks.md updated
  Periodically: SecondBrain/ updated with learnings
```

## Tool Compatibility

| Tool | How to use this system |
|---|---|
| Claude Code | CLAUDE.md auto-loads; reads .ai/ per instructions |
| Cursor | Paste `.agents/[role].md` content as system prompt |
| GPT / ChatGPT | Paste `.ai/memory.md` + `.ai/handoff.md` into first message |
| Kilo AI / OpenCode | Same as GPT — prepend .ai/ files to context |
| Any future tool | Same pattern — .ai/ is plain text, always accessible |
