# AGENTS.md — Universal AI Session Protocol

This file is the **single source of truth** for every AI coding tool and assistant used in this workspace. Read it first. Every other rule file (`CLAUDE.md`, `.cursorrules`, `.windsurfrules`, `.kilocode/rules.md`) is a pointer here.

Target tools: Claude Code, Cursor, Antigravity, Kilo AI, OpenCode, Zed, Windsurf, GPT/Codex, Gemini Code Assist, and any future agent.

---

## 1. Session Start Protocol (do this before any task)

1. Read `.ai/handoff.md` — last session state, blockers, next actions. **Always.**
2. Read `.ai/memory.md` section index (top 15 lines) — load only the sections relevant to the task.
3. If the user specifies a role: load `.agents/<role>.md`.
4. Confirm context loaded in one line: `"Loaded: handoff + memory[sections] + <role>."` Then wait for the task.

**Do not** read `architecture.md`, `decisions.md`, or `coding_rules.md` unless the task requires them. Token budget is finite.

---

## 2. Session End Protocol (do this after meaningful work)

1. Update `.ai/handoff.md` — what was done, blockers, next actions. Keep under 25 lines.
2. Update `.ai/tasks.md` — check off completed tasks, add new ones discovered.
3. If a major decision was made → append an entry to `.ai/decisions.md` with Decision / Reason / Trade-off.
4. Never summarize work only in chat. It will be lost. Write it to `handoff.md`.

### Rotation (when size caps are hit — do not silently violate them)
- `handoff.md` exceeds 25 lines → move the "What Was Completed" section to `SecondBrain/Daily Notes/YYYY-MM-DD.md` (append-only history) before writing new entries. `handoff.md` stays a 25-line current-state snapshot.
- `.ai/memory.md` section exceeds 50 lines → split that section into `.ai/memory-<topic>.md` and update the index at the top of `memory.md`.
- `.ai/tasks.md` exceeds 50 lines → move completed items to `SecondBrain/Daily Notes/YYYY-MM-DD.md`.
- `.ai/decisions.md` exceeds 50 lines → split by year: keep the current year in `.ai/decisions.md`, move older entries to `SecondBrain/Decisions/YYYY.md`.

---

## 3. File Map

### Repo memory (per project — framework-agnostic)
| File | Purpose | Load when |
|---|---|---|
| `.ai/handoff.md` | Last session state → next actions | **Always, first** |
| `.ai/memory.md` | Project identity, stack, constraints | Every session, scoped to section |
| `.ai/tasks.md` | Sprint tasks + backlog | Task planning, end of session |
| `.ai/architecture.md` | Modules, services, data flow | Only when working on structure |
| `.ai/decisions.md` | Dated decision log | Only when revisiting a choice |
| `.ai/coding_rules.md` | Style, conventions, AI rules | Only when uncertain of convention |

### Agent roles (per project — framework-agnostic)
| Role | File | Use for |
|---|---|---|
| Architect | `.agents/architect.md` | System design, structure, data flow |
| Debugger | `.agents/debugger.md` | Root cause, minimal fixes |
| Refactor | `.agents/refactor.md` | Clean code, readability |
| PM | `.agents/pm.md` | Task prioritization, milestones |
| Reviewer | `.agents/reviewer.md` | Code quality, risk |
| Assistant | `.agents/assistant.md` | Daily general-purpose helper |
| Scheduler | `.agents/scheduler.md` | Time-blocking, daily plan |
| Reminder | `.agents/reminder.md` | Reminders, accountability |

Activate a role by telling the AI: *"Use the `<role>` role."* The agent file prepends the session protocol above.

### Strategic vault (cross-project — `SecondBrain/`)
Obsidian vault. Long-term knowledge: `Projects/`, `Knowledge/`, `Prompts/`, `Decisions/`, `Bugs/`, `Learnings/`, `Daily Notes/`, `Templates/`, `Assistant/` (daily state for the assistant agents).

---

## 4. Token-Saving Rules (enforced, not optional)

- **Scoped reads only.** Say *"Read `.ai/memory.md` Stack section"* — not *"Read `.ai/memory.md`"*.
- **One task per session.** Start a new chat for unrelated topics. Long threads compound tokens and slow reasoning.
- **Never re-explain project context in chat.** It lives in `.ai/memory.md`. Reference it, don't paste it.
- **Prefer one well-scoped request** over five clarification rounds.
- **Cheap tools for cheap tasks.** Claude Code / GPT-5 / Opus for design, debugging, architecture. Cursor tab / Kilo / local models for syntax fixes, boilerplate, tiny edits.
- **File size caps:** `.ai/*` files stay under 50 lines each. `handoff.md` under 25. If a file grows, split it.
- **Indexers:** `.cursorignore`, `.kilocodeignore`, `.aiexclude`, `.codeiumignore` exclude `.obsidian/` + build output (`node_modules`, `dist`, `build`, `.venv`, `__pycache__`). `SecondBrain/` stays **indexed** so reusable prompts, decisions, and learnings are searchable across tools.

---

## 5. Bootstrap for tools without auto-load

Tools like ChatGPT, generic Kilo, or a fresh GPT chat won't auto-load anything. Paste this as your first message (stored in `SecondBrain/Prompts/bootstrap.md`):

> Read `.ai/handoff.md` and the index at the top of `.ai/memory.md`. If the task requires it, also read the matching section of `.ai/memory.md`. Follow the session protocol in `AGENTS.md`. Confirm loaded, then await task.

---

## 6. Cross-Tool Cheat Sheet

| Tool | Entrypoint | Behavior |
|---|---|---|
| Claude Code | `CLAUDE.md` + `.claude/rules/*.md` → AGENTS.md | Auto-loads `CLAUDE.md` and every file under `.claude/rules/`. Does **not** auto-read `AGENTS.md`; `CLAUDE.md` redirects it there. |
| Cursor | `.cursor/rules/*.mdc` (native) + `.cursorrules` (legacy) → AGENTS.md | Auto-loads `.cursor/rules/*.mdc` with `alwaysApply: true`. `.cursorrules` is legacy but still honored. |
| Windsurf | `.windsurfrules` → AGENTS.md | Auto-loads `.windsurfrules`. |
| Kilo AI | `.kilocode/rules.md` → AGENTS.md | Auto-loads `.kilocode/rules.md`. |
| Zed | `AGENTS.md` (native) | Reads `AGENTS.md` directly. |
| Antigravity | `AGENTS.md` (native) | Reads `AGENTS.md` directly. |
| OpenCode | `AGENTS.md` (native) | Reads `AGENTS.md` directly. |
| Codex / GPT | Paste `SecondBrain/Prompts/bootstrap.md` | Manual — no auto-load. |
| Gemini Code Assist | `.aiexclude` respected + manual bootstrap | Manual — no auto-load. |

To add a new tool: drop a pointer file in its expected location, have it say "Session protocol lives in `AGENTS.md`. Read it first." That's the entire integration.

---

## 7. Principle

> Stateless high-value reasoning engine + persistent markdown memory + scoped role prompts = portable AI teammate.

Claude / GPT / Cursor are **consultants**, not memory. Memory lives here on disk.
