# Claude Code Instructions

**Canonical rules live in `AGENTS.md`. Read it first.** This file only adds Claude-Code-specific notes.

## Session start
1. Read `AGENTS.md` — session protocol, file map, token rules.
2. Follow the protocol there (handoff.md → memory.md index → optional role).

## Claude-Code-specific rules
- `.claude/rules/*.md` are **auto-loaded enforcement mirrors** of sections from `AGENTS.md`. `AGENTS.md` is the source; edit it first, then update the mirrors. Run `bash scripts/check-drift.sh` to verify they stay in sync.
- Use agent roles via: *"Use the `<role>` role."* — roles live in `.agents/`.
- Prefer `Edit` / `Read` / `Write` tools over shell `cat`/`sed`/`echo` for file operations.

## If you are any other AI tool reading this
You are in the wrong file. Go to `AGENTS.md`.
