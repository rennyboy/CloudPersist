# Decisions

<!-- Append entries in this format:

## [YYYY-MM-DD] — Short Title
**Decision**: What was decided — one sentence.
**Reason**: Why this over alternatives.
**Trade-off**: What was given up.
**Revisit if**: Condition that would make us reconsider.

-->
