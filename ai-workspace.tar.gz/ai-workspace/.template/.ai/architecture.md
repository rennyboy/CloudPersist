# Architecture

_Fill in when structure emerges. Keep under 50 lines — split into topic files if it grows._

## Modules

## Data Flow

## External Services
