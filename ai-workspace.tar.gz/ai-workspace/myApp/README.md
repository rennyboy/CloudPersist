# AI Workspace — Persistent Memory & Agent Workflow

Model-agnostic persistent memory system for solo AI-powered builders. Eliminates repeated prompting, preserves context across sessions and tools, enables seamless handoff between AI models.

> **Principle:** AI tools are stateless reasoning engines, not memory. Memory lives on disk.

---

## Folder Structure

```
ai-workspace/
├── AGENTS.md              ← Single source of truth (session protocol)
├── CLAUDE.md              ← Pointer to AGENTS.md (Claude Code auto-loads)
├── README.md              ← You are here
├── new-project.sh         ← Scaffold a new project
├── .ai/                   ← This workspace's own memory
│   ├── memory.md          ← Identity, stack, priorities, rules
│   ├── handoff.md         ← Session state (always read first)
│   ├── tasks.md           ← Sprint tasks + backlog
│   └── decisions.md       ← Why choices were made
├── .agents/               ← Role prompts for focused AI behavior
│   ├── architect.md       ← System design, data flow
│   ├── coder.md           ← Implementation, debugging, refactoring
│   ├── reviewer.md        ← Code quality, risk detection
│   └── assistant.md       ← Personal productivity (schedule/reminders)
├── .template/             ← Scaffold copied by new-project.sh
│   ├── .ai/               ← Blank templates for new projects
│   ├── .agents/           ← Role files for new projects
│   ├── AGENTS.md, CLAUDE.md, .cursorrules, .gitignore
├── SecondBrain/            ← Obsidian vault (cross-project knowledge)
│   ├── Projects/           ← One note per active project
│   ├── Knowledge/          ← Technical concepts and research
│   ├── Prompts/            ← Reusable AI prompts (incl. bootstrap.md)
│   ├── Decisions/          ← Strategic decisions
│   ├── Bugs/               ← Recurring bug patterns
│   ├── Learnings/          ← Mistakes and lessons
│   ├── Daily Notes/        ← Per-day reflections
│   ├── Templates/          ← Reference copies of .ai/ templates
│   └── Assistant/          ← Daily state (schedule, reminders, inbox)
```

---

## Quick Start

### With Claude Code, Zed, Antigravity, OpenCode
Just open the project. `CLAUDE.md` or `AGENTS.md` auto-loads. Say:
> Use the architect role. Task: [your task].

### With Cursor
`.cursorrules` auto-loads → points to `AGENTS.md`. Same pattern.

### With Windsurf
`.windsurfrules` auto-loads → points to `AGENTS.md`.

### With ChatGPT / GPT / Codex (no auto-load)
Paste `SecondBrain/Prompts/bootstrap.md` as your first message.

---

## Scaffold a New Project

```bash
bash new-project.sh <target-path>
```

This copies `.template/` into the target, fills in the project name and date, and gives you a ready-to-use `.ai/` + `.agents/` + pointer files.

Then: `cd <target-path>` → fill in `.ai/memory.md` → open your AI tool → *"Use the architect role. Design the initial structure."*

---

## Cross-Tool Compatibility

| Tool | Entrypoint | Notes |
|---|---|---|
| Claude Code | `CLAUDE.md` → `AGENTS.md` | Auto-loads |
| Cursor | `.cursorrules` → `AGENTS.md` | Auto-loads |
| Windsurf | `.windsurfrules` → `AGENTS.md` | Auto-loads |
| Kilo AI | `.kilocode/rules.md` → `AGENTS.md` | Auto-loads |
| Zed / Antigravity / OpenCode | `AGENTS.md` natively | Auto-loads |
| ChatGPT / GPT / Codex | Paste `bootstrap.md` | Manual |
| Gemini Code Assist | `.aiexclude` + manual bootstrap | Manual |

---

## Token-Saving Checklist

- [ ] Scoped reads: *"Read memory.md Stack section"* not the whole file
- [ ] One task per session — fresh chat for unrelated work
- [ ] Never re-paste context in chat — reference `.ai/` file paths
- [ ] Use cheap models (Cursor tab, Kilo) for syntax fixes, boilerplate
- [ ] Reserve Opus / GPT-5 for design, debugging, architecture
- [ ] Keep `.ai/*` ≤50 lines, `handoff.md` ≤25 lines
- [ ] Verify ignore files exclude `SecondBrain/`, `.obsidian/`
