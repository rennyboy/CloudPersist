# Claude Code Instructions

**Canonical rules live in `AGENTS.md`. Read it first.** This file only adds Claude-specific notes.

## Session start
1. Read `AGENTS.md` — session protocol, file map, token rules.
2. Follow the protocol (handoff.md → memory.md index → optional role).

## Claude-specific
- Use agent roles via: *"Use the `<role>` role."* — roles live in `.agents/`.
- Prefer Edit / Read / Write tools over shell `cat`/`sed`/`echo`.

## If you are any other AI tool reading this
Go to `AGENTS.md`.
