# AGENTS.md — Session Protocol

This file is the **single source of truth** for every AI tool in this workspace.

---

## 1. Session Start (do this before any task)

1. Read `.ai/handoff.md` — last session state, blockers, next actions. **Always.**
2. Read `.ai/memory.md` section index (top 15 lines) — load only relevant sections.
3. If a role is specified: load `.agents/<role>.md`.
4. Confirm: `"Loaded: handoff + memory[sections] + <role>."` Then wait for the task.

**Do not** load all of `.ai/memory.md`. Scoped reads only.

---

## 2. Session End (after meaningful work)

1. Update `.ai/handoff.md` — what was done, blockers, next actions. Keep ≤25 lines.
2. Update `.ai/tasks.md` — check off completed, add new ones discovered.
3. If a major decision was made → append to `.ai/decisions.md`.
4. Never summarize work only in chat. Write it to `handoff.md`.

---

## 3. Files

| File | Purpose | Load when |
|---|---|---|
| `.ai/handoff.md` | Session state → next actions | **Always, first** |
| `.ai/memory.md` | Project identity, stack, rules, architecture | Every session, scoped |
| `.ai/tasks.md` | Sprint tasks + backlog | Task planning |
| `.ai/decisions.md` | Dated decision log | Revisiting choices |

## 4. Roles

| Role | File | Use for |
|---|---|---|
| Architect | `.agents/architect.md` | System design, structure, data flow |
| Coder | `.agents/coder.md` | Implementation, debugging, refactoring |
| Reviewer | `.agents/reviewer.md` | Code quality, risk, standards |

Activate: *"Use the `<role>` role."*

---

## 5. Token Rules

- **Scoped reads only.** *"Read memory.md Stack section"* — not the whole file.
- **One task per session.** Fresh chat for unrelated work.
- **Never re-explain context in chat.** Reference `.ai/` files.
- `.ai/*` files ≤50 lines. `handoff.md` ≤25 lines.
