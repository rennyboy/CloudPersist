# Decision Log

## [YYYY-MM-DD] — [Short Decision Title]
**Decision**: [What was decided — one sentence]
**Reason**: [Why this was chosen over alternatives]
**Trade-off**: [What was given up or accepted as a downside]
**Revisit if**: [Condition that would make us reconsider]
