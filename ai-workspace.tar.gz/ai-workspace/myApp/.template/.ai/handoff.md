# Session Handoff

## Last Updated
[YYYY-MM-DD]

## What Was Completed
- [Task or feature finished]

## Current Blockers
- None

## Immediate Next Actions
1. [First thing to do next session]
2. [Second thing]
3. [Third thing if needed]

## Notes for Next Session
[Any context that won't be obvious from the code — temp state, in-progress work, gotchas]
