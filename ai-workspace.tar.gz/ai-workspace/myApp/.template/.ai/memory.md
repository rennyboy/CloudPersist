# Project Memory

## Index
<!-- AI: read only the sections relevant to your task -->
- Identity
- Purpose
- Stack
- Priorities
- Constraints
- Coding Rules

## Identity
- **Name**: [Project Name]
- **Owner**: [your name / email]
- **Created**: [YYYY-MM-DD]

## Purpose
[One paragraph: what does this project do and why does it exist?]

## Stack
- **Backend**: [e.g. Laravel 11, Node.js]
- **Frontend**: [e.g. React, Blade, Vue]
- **Database**: [e.g. PostgreSQL, MySQL]
- **Hosting**: [e.g. DigitalOcean, Vercel]
- **Other**: [queues, cache, external APIs]

## Priorities
1. [Most important thing right now]
2. [Second priority]
3. [Third priority]

## Constraints
- [Hard deadline, if any]
- [Budget limit, if any]
- [Technical constraints — legacy code, must use X, etc.]
- [Scope limits — what is explicitly out of scope]

## Coding Rules
- [Style rules — indentation, naming, etc.]
- [Architecture preferences — folder structure, patterns]
- [Conventions — commit messages, branch naming, etc.]

## Key Context
[Anything an AI agent would need to know that isn't obvious from the code]
