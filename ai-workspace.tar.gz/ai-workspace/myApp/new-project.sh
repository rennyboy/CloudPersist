#!/usr/bin/env bash
# new-project.sh — scaffold a new project with the AI workspace protocol.
# Usage: bash new-project.sh <target-path>

set -euo pipefail

if [[ $# -ne 1 ]]; then
  echo "Usage: $0 <target-path>" >&2
  exit 1
fi

TARGET="$1"
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
TEMPLATE="$SCRIPT_DIR/.template"

if [[ ! -d "$TEMPLATE" ]]; then
  echo "Template folder missing: $TEMPLATE" >&2
  exit 1
fi

if [[ -e "$TARGET" && -n "$(ls -A "$TARGET" 2>/dev/null || true)" ]]; then
  echo "Target exists and is not empty: $TARGET" >&2
  exit 1
fi

mkdir -p "$TARGET"
cp -r "$TEMPLATE/." "$TARGET/"

NAME="$(basename "$(cd "$TARGET" && pwd)")"
TODAY="$(date +%Y-%m-%d)"
sed -i "s/\[Project Name\]/$NAME/" "$TARGET/.ai/memory.md"
sed -i "s/\[YYYY-MM-DD\]/$TODAY/g" "$TARGET/.ai/memory.md"
sed -i "s/\[YYYY-MM-DD\]/$TODAY/" "$TARGET/.ai/handoff.md"

cat <<EOF
✅ Scaffold created at $TARGET

Contents:
  .ai/          memory.md, handoff.md, tasks.md, decisions.md
  .agents/      architect.md, coder.md, reviewer.md
  AGENTS.md     Session protocol
  CLAUDE.md     Claude Code pointer
  .cursorrules  Cursor pointer
  .gitignore    Excludes local AI overrides

Next:
  1. cd "$TARGET" && fill in .ai/memory.md (Purpose, Stack, Priorities)
  2. Open your AI tool and say: "Use the architect role. Design the initial structure."
EOF
