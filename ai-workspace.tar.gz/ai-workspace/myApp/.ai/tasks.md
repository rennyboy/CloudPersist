# Tasks

## Active Sprint
- [x] Design and implement the AI Workspace persistent memory system
- [x] Create AGENTS.md, .ai/, .agents/, SecondBrain/
- [x] Audit and streamline the system (remove duplication, create missing dirs)
- [ ] Apply `.ai/` template to first real project
- [ ] Test each agent role in a real session
- [ ] Populate SecondBrain/Prompts/ with 3 reusable prompts
- [ ] Test cross-tool handoff: Claude → Cursor → GPT

## Backlog
- [ ] Create daily note template in SecondBrain/Daily Notes/
- [ ] Set up git for the workspace
- [ ] Add .windsurfrules pointer file
- [ ] Add .kilocode/rules.md pointer file
- [ ] Write a "project retrospective" prompt for SecondBrain/Prompts/
