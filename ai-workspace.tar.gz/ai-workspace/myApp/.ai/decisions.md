# Decision Log

## 2026-04-24 — Markdown over database for memory storage
**Decision**: All memory is plain markdown files, not a database or structured API.
**Reason**: Zero setup, zero dependencies, works offline, readable by humans and all AI tools.
**Trade-off**: No query power. Acceptable at solo-builder scale.
**Revisit if**: Multi-user collaboration requires structured queries.

## 2026-04-24 — Obsidian as the vault tool
**Decision**: `SecondBrain/` is an Obsidian vault.
**Reason**: Local-first, markdown-native, strong graph/linking features.
**Trade-off**: Machine-local until sync is configured. Obsidian features don't work in other editors.
**Revisit if**: Need cloud-native collaboration or mobile-first access.

## 2026-04-24 — AI tools are stateless workers, not memory
**Decision**: Claude/GPT/Cursor are reasoning engines. Memory lives in files.
**Reason**: AI sessions reset. Files don't. Separation of concerns.
**Revisit if**: AI tools gain reliable persistent memory natively.

## 2026-04-24 — Reduced agent roles from 8 to 4
**Decision**: Ship with architect, coder, reviewer, assistant. Dropped debugger, refactor, pm, scheduler, reminder as standalone roles.
**Reason**: Debugger and refactor merged into coder. PM/scheduler/reminder are niche — add only when proven needed.
**Trade-off**: Less specialization per role. Coder role is broader.
**Revisit if**: A merged role consistently underperforms a specialized one.
