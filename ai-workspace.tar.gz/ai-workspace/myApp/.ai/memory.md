# Project Memory

## Index
<!-- AI: read only the sections relevant to your task -->
- Identity
- Purpose
- Stack
- Priorities
- Constraints
- Coding Rules
- Architecture

## Identity
- **Name**: AI Workspace
- **Owner**: rennyboy
- **Created**: 2026-04-24

## Purpose
Model-agnostic persistent memory and agent workflow system for solo AI-powered builders. Eliminates repeated prompting, preserves context across sessions and tools.

## Stack
- **Runtime**: Plain markdown files — no database, no dependencies
- **Vault**: Obsidian (SecondBrain/)
- **Compatibility**: Claude Code, Cursor, Antigravity, Kilo AI, OpenCode, Zed, Windsurf, GPT/Codex, Gemini
- **Scaffolding**: Bash (`new-project.sh`)

## Priorities
1. Get `.ai/` + `.agents/` working in a real project
2. Populate SecondBrain/Prompts/ with battle-tested prompts
3. Validate cross-tool handoff (Claude → Cursor → GPT)

## Constraints
- All `.ai/*` files ≤50 lines; `handoff.md` ≤25 lines
- No secrets in `.ai/` — plain text, git-tracked
- SecondBrain/ excluded from AI indexing (`.cursorignore`, `.aiexclude`)

## Coding Rules
- Markdown only — no YAML, no JSON config, no database
- One canonical source: `AGENTS.md` wins every conflict
- Pointer files (CLAUDE.md, .cursorrules) contain zero logic — only redirect to AGENTS.md
- Templates live in `.template/`; SecondBrain/Templates/ is reference copy

## Architecture
- **Layer 1** — `.ai/`: per-project execution state (handoff, memory, tasks, decisions)
- **Layer 2** — `SecondBrain/`: cross-project strategic vault (Obsidian)
- **Layer 3** — `.agents/`: role prompts that focus AI behavior per task type
- Protocol flow: tool pointer → AGENTS.md → .ai/handoff.md → .ai/memory.md[section] → role
