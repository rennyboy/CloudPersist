# AGENTS.md — Universal AI Session Protocol

This file is the **single source of truth** for every AI coding tool and assistant used in this workspace. Read it first. Every other rule file (`CLAUDE.md`, `.cursorrules`, `.windsurfrules`, `.kilocode/rules.md`) is a pointer here.

---

## 1. Session Start (do this before any task)

1. Read `.ai/handoff.md` — last session state, blockers, next actions. **Always.**
2. Read `.ai/memory.md` section index (top 15 lines) — load only the sections relevant to the task.
3. If the user specifies a role: load `.agents/<role>.md`.
4. Confirm context loaded in one line: `"Loaded: handoff + memory[sections] + <role>."` Then wait for the task.

**Do not** read all of `.ai/memory.md`. Scoped reads only. Token budget is finite.

---

## 2. Session End (do this after meaningful work)

1. Update `.ai/handoff.md` — what was done, blockers, next actions. Keep ≤25 lines.
2. Update `.ai/tasks.md` — check off completed tasks, add new ones discovered.
3. If a major decision was made → append to `.ai/decisions.md` with Decision / Reason / Trade-off / Revisit-if.
4. Never summarize work only in chat. It will be lost. Write it to `handoff.md`.

---

## 3. File Map

### Repo memory (per project)
| File | Purpose | Load when |
|---|---|---|
| `.ai/handoff.md` | Session state → next actions | **Always, first** |
| `.ai/memory.md` | Project identity, stack, rules, architecture | Every session, scoped to section |
| `.ai/tasks.md` | Sprint tasks + backlog | Task planning, end of session |
| `.ai/decisions.md` | Dated decision log | Only when revisiting a choice |

### Agent roles (per project)
| Role | File | Use for |
|---|---|---|
| Architect | `.agents/architect.md` | System design, structure, data flow |
| Coder | `.agents/coder.md` | Implementation, debugging, refactoring |
| Reviewer | `.agents/reviewer.md` | Code quality, risk, standards |
| Assistant | `.agents/assistant.md` | Personal productivity (schedule, reminders, inbox) |

Activate a role by telling the AI: *"Use the `<role>` role."*

### Strategic vault (cross-project — `SecondBrain/`)
Obsidian vault for long-term knowledge: `Projects/`, `Knowledge/`, `Prompts/`, `Decisions/`, `Bugs/`, `Learnings/`, `Daily Notes/`, `Templates/`, `Assistant/`.

---

## 4. Token-Saving Rules (enforced, not optional)

- **Scoped reads only.** *"Read `.ai/memory.md` Stack section"* — not the whole file.
- **One task per session.** Start a new chat for unrelated topics.
- **Never re-explain project context in chat.** Reference `.ai/` files.
- **Prefer one well-scoped request** over five clarification rounds.
- **File size caps:** `.ai/*` ≤50 lines each. `handoff.md` ≤25 lines. Split if growing.
- **Indexers:** `.cursorignore`, `.kilocodeignore`, `.aiexclude` exclude `SecondBrain/`, `.obsidian/`.

---

## 5. Bootstrap for tools without auto-load

Tools like ChatGPT or GPT that don't auto-load rules: paste `SecondBrain/Prompts/bootstrap.md` as your first message. See `README.md` for the full cross-tool compatibility table.
