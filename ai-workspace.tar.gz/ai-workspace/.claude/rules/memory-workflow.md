# Memory Workflow Rules

> **Enforcement mirror of `AGENTS.md` §1 and §2.** `AGENTS.md` is the source of truth. Edit it first, then sync here. Run `bash scripts/check-drift.sh` to verify.

## Session start (from AGENTS.md §1)
1. Read SecondBrain always-loaded indexes:
   - `SecondBrain/INDEX.md`
   - `SecondBrain/Errors/INDEX.md` — failure library, scan for relevant symptoms
   - `SecondBrain/Knowledge/INDEX.md` — distilled rules
   - `SecondBrain/Decisions/INDEX.md` — active major decisions
   - `SecondBrain/Projects/INDEX.md` — confirm project is registered
2. Read `.ai/handoff.md` — last session state, blockers, next actions. **Always.**
3. Read `.ai/memory.md` section index (top 15 lines) — load only sections relevant to the task.
4. If the user specifies a role: load `.agents/<role>.md`.
5. Confirm: `"Loaded: brain[errors,knowledge,decisions,projects] + handoff + memory[sections] + <role>."` Then wait for task.

Do **not** read individual SecondBrain entry files unless an INDEX row matches the task. Do **not** read `architecture.md`, `decisions.md`, or `coding_rules.md` unless required.

## Session end (from AGENTS.md §2)
1. Update `.ai/handoff.md` — what was done, blockers, next actions. ≤25 lines.
2. Update `.ai/tasks.md` — check off completed, add new.
3. If a major decision was made → append to `.ai/decisions.md` (Decision / Reason / Trade-off). If it generalizes → also capture in `SecondBrain/Decisions/` via `Templates/decision.md`.
4. **If an error/surprise hit:** run `SecondBrain/Prompts/error-capture.md`. Either bump `Hits` on an existing `Errors/INDEX.md` row or create a new entry. **The brain only evolves if errors are captured.**
5. **If a non-obvious observation:** drop into `SecondBrain/Learnings/` (staging for Knowledge promotion).
6. Never summarize work only in chat — write to `handoff.md` or the appropriate SecondBrain location.

## Rotation (when caps are hit)
- `handoff.md` > 25 lines → move "What Was Completed" to `SecondBrain/Daily Notes/YYYY-MM-DD.md` before writing new entries.
- `.ai/memory.md` section > 50 lines → split into `.ai/memory-<topic>.md` and update the index.
- `Errors/INDEX.md` > 200 lines → run `Prompts/promotion-review.md` to distill ripe entries.
- `Knowledge/INDEX.md` > 100 lines → archive stale entries to `Knowledge/archive/`.
